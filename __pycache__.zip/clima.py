
import requests


def obtener_clima(ciudad: str) -> dict:
    """Obtiene los datos meteorológicos actuales de una ciudad."""
    url = "https://wttr.in/" + ciudad
    parametros = {"format": "j1"}

    respuesta = requests.get(url, params=parametros, timeout=10)
    respuesta.raise_for_status()

    datos = respuesta.json()
    return datos
